#!/usr/bin/env python

#  for i in range(100, 2, -2):
##    print i

for i in range(1, 100, 1):
    if i % 4 == 0 and i % 5== 0:
        print(str(i) + ": GoFigure")
    elif i % 4 == 0:
        print(str(i) + ": Go")
    elif i% 5 == 0:
        print(str(i) + ": Figure")